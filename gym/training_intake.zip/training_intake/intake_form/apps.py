from django.apps import AppConfig


class IntakeFormConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'intake_form'
