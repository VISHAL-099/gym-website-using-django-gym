# views.py
from django.shortcuts import render, redirect, get_object_or_404
from .forms import ClientIntakeForm
from .models import ClientIntake


def intake_form_view(request):
    if request.method == "POST":
        form = ClientIntakeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('success')
    else:
        form = ClientIntakeForm()
    return render(request, 'intake_form.html', {'form': form})

def success_view(request):
    return render(request, 'success.html')

def view_submitted_requests(request):
    # Fetch all submitted requests from the database
    submissions = ClientIntake.objects.all()
    return render(request, 'submitted_requests.html', {'submissions': submissions})

def submission_detail(request, submission_id):
    # Fetch a specific submission by its ID
    submission = get_object_or_404(ClientIntake, id=submission_id)
    return render(request, 'submission_detail.html', {'submission': submission})