# urls.py
from django.urls import path
from .views import intake_form_view, success_view, view_submitted_requests, submission_detail

urlpatterns = [
    path('', intake_form_view, name='intake_form'),
    path('success/', success_view, name='success'),
    path('submitted-requests/', view_submitted_requests, name='submitted_requests'),
    path('submission/<int:submission_id>/', submission_detail, name='submission_detail'),
]